### Date created
July.26 2020

# Post your Work on GitHub

### Description
In this project, you'll be simulating a realistic workflow to refactor your previous Project 2 using Git.

### List of software, firmware and hardware you may require.
* Installing GIT tool : https://git-scm.com/downloads.

### Files used
1. The following file contains necessary commands used to do tasks:
   * Git Commands Documentation.pdf	
2. The following files helps to understand the Git key terms:
   * Git-KeyTerms.pdf

### Credits
* [Git documentation is very usefull.](https://git-scm.com/doc)
